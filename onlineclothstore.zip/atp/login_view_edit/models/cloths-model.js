var db = require('./db');

module.exports= {
	getById : function(id, callback){
		var sql = "select * from cloths where id=?";
		db.getResults(sql, [id], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll : function(callback){
		var sql = "select * from cloths";
		db.getResults(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insert: function(user, callback){
		var sql = "insert into cloths values(?,?,?)";
		db.execute(sql, [user.name, user.type, user.price], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	delete: function(user, callback){
		var sql = "delete from cloths where id=?";
		db.execute(sql, [user.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}